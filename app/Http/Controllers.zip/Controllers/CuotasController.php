<?php

namespace App\Http\Controllers;

use App\Cuotas;
use Illuminate\Http\Request;

class CuotasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $cuotas=new Cuotas();

        $cuotas->deuda_id=$request->deuda_id;
        $cuotas->nombre_cuota=$request->nombre_cuota;
        $cuotas->cantidad_cuota=$request->cantidad_cuota;
        $cuotas->save();
        $data=[
            "message"=>"success",
            "status"=>200
        ];

        return response()->json($data);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Cuotas  $cuotas
     * @return \Illuminate\Http\Response
     */
    public function show(Cuotas $cuotas)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Cuotas  $cuotas
     * @return \Illuminate\Http\Response
     */
    public function edit(Cuotas $cuotas)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Cuotas  $cuotas
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Cuotas $cuotas)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Cuotas  $cuotas
     * @return \Illuminate\Http\Response
     */
    public function destroy(Cuotas $cuotas)
    {
        //
    }
}
